function blkStruct = slblocks


blkStruct.Name = 'Soft Real Time Lib';
blkStruct.OpenFcn = 'utility';
blkStruct.MaskInitialization = '';




