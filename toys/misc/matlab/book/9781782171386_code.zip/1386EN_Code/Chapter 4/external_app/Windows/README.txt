In order to run the application (alfa147gta.exe) you need to
keep the DLL files and the 'platforms' folder together with the application.

Copy the parent folder to your computer. Don't run the application
from a USB pen or similar, because the performance will be a lot worse
(it opens and closes three files each execution cycles).