void test_012_testing_change_prio_same();
