void test_006_testing_sem_take_and_release();
