void test_007_testing_flags();
