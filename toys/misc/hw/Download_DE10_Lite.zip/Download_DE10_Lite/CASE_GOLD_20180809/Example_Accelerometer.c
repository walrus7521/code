#include <stdio.h>
#include <alt_types.h>
#include <altera_up_avalon_accelerometer_spi.h>

int main() {
alt_32 x_data,y_data,z_data;

// Initialize accelerometer
alt_up_accelerometer_spi_dev* accelerometer=alt_up_accelerometer_spi_open_dev(ACCELEROMETER_SPI_0_NAME);
alt_u8 accelerometer_available=(accelerometer!=0);
if(!accelerometer_available) {
	printf("Failed to obtain accelerometer device pointer\n");
	}

while(1) {
	// Read and print accelerometer values
	alt_up_accelerometer_spi_read_x_axis(accelerometer,&x_data);
		alt_up_accelerometer_spi_read_y_axis(accelerometer,&y_data);
		alt_up_accelerometer_spi_read_z_axis(accelerometer,&z_data);
	printf("acc; x: %d, y: %d, z: %d\n",(int)x_data,(int)y_data,(int)z_data);
// type conversion from alt_32 to int

// delay to get a reasonable rate
int i;
for(i=0;i<100000;i++) {};
	}
return 0;
}
