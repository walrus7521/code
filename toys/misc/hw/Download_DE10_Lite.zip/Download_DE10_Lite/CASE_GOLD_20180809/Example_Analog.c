#include <stdio.h>
#include <system.h>
#include <alt_types.h>
#include <altera_modular_adc.h>

#define ANALOG_VOLTAGE_REFERENCE 2.5f
#define CH1 0
#define CH2 1
#define CH3 2
#define CH4 3
#define CH5 4
#define CH6 5
#define SLOT_OFFSET 4

int main() {
	printf("Starting system\n");

	// Enable analog input from ADC in continuous mode
	adc_set_mode_run_continuously(MODULAR_ADC_0_SEQUENCER_CSR_BASE);
	adc_start(MODULAR_ADC_0_SEQUENCER_CSR_BASE);

	alt_u32 ii;
	alt_u32 reading;

	while(1) {
	// Read TMP36 temperature sensor from arduino PIN_A0
	alt_adc_word_read(MODULAR_ADC_0_SAMPLE_STORE_CSR_BASE+
(CH1*SLOT_OFFSET),&reading,1);
	alt_u32 pin_a0_reading=reading;

	// Read 1Kohm potentiometer sensor from arduino PIN_A2
	alt_adc_word_read(MODULAR_ADC_0_SAMPLE_STORE_CSR_BASE+
(CH3*SLOT_OFFSET),&reading,1);
	alt_u32 pin_a2_reading=reading;

	// Read Photoresiostor sensor from arduino PIN_A4
	alt_adc_word_read(MODULAR_ADC_0_SAMPLE_STORE_CSR_BASE+
(CH5*SLOT_OFFSET),&reading,1);
	alt_u32 pin_a4_reading=reading;

	// Convert reading to voltage and celsius
	float voltage=((pin_a0_reading<<1)*ANALOG_VOLTAGE_REFERENCE)/4096.0f;
	float temperature_c=(voltage-0.5f)*100.0f;
	float potvolt=((pin_a2_reading<<1)*ANALOG_VOLTAGE_REFERENCE)/4096.0f;
	float voltlight=((pin_a4_reading<<1)*ANALOG_VOLTAGE_REFERENCE)/4096.0f;

	// Print collected data
	printf("Temp: %.2f celsius (%.2fv)\tPotentiometer %.2fv\tLjus %.2fv \n",temperature_c,voltage,potvolt,voltlight);

	// Delay
	ii=0;
	while(ii<500000){
		ii++;
	}
	}
	return 0;
}
