#include <stdio.h>
#include <system.h>
#include <alt_types.h>
#include <altera_avalon_pio_regs.h>
#include <altera_up_avalon_rs232.h>

int main() {

	printf("Starting software system\n");

	char rx_buffer[127];
	char tx_buffer[127]; // AT test
	char *send_buffer;
	alt_u8 rx_txt;
	alt_u8 par_e;
	alt_32 fifo_lenght,ii;
	alt_u32 led0=1;
	alt_u32 PIO_REG = 0x0;

//open rs232
	alt_up_rs232_dev* rs232_if= alt_up_rs232_open_dev(RS232_0_NAME);
	alt_u8 rs232_available=(rs232_if!=0);
	if(!rs232_available) {
		printf("Failed to obtain Serial device pointer\n");
	}else{
		char AT_buffer[] = "AT+VERSION";
		for(ii=0;ii<10;ii++){					alt_up_rs232_write_data(rs232_if,AT_buffer[ii]);
	}
	ii=0;//wait for reply
	while(ii<500000){
		ii++;}
	fifo_lenght = alt_up_rs232_get_used_space_in_read_FIFO(rs232_if);
	if(fifo_lenght!=0){
// AT mode
		printf("Connection to: ");
	}else{
// Connected to bluetooth terminal
	   printf("Serial connection 9600baud 1 stopbit no parity.\n");
		}
	}

	while(1) {
//Check if anything is received
	 fifo_lenght = alt_up_rs232_get_used_space_in_read_FIFO(rs232_if);

	 if(fifo_lenght!=0){
		for(ii=0;ii<fifo_lenght;ii++){
		alt_up_rs232_read_data(rs232_if,&rx_txt,&par_e);
		rx_buffer[ii] = rx_txt;
		}
	 rx_buffer[fifo_lenght] = '\0';
	 printf("%s\n",rx_buffer);//show what was received on Nios console
		}

//check led status
	 PIO_REG = IORD_ALTERA_AVALON_PIO_DATA(PIO_LEDS_OUT_BASE);
// testing if a zero '0' was received
	 if(rx_buffer[0]==0x30){
		printf("received:0 led=%d\n",led0); //Nios console
		if(led0==0){
		send_buffer = "Ledr_0 OFF\n";//Bluetooth console
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_LEDS_OUT_BASE,PIO_REG & led0);
		led0 =1;
		}else{
		send_buffer = "Ledr_0 ON \n";//Bluetooth console
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_LEDS_OUT_BASE,PIO_REG | led0);
		led0 =0;
		}
	//send message to bluetooth terminal
	 for(ii=0;ii<11;ii++){
		alt_up_rs232_write_data(rs232_if,send_buffer[ii]);
	}
	}

//Reset  buffers
	 rx_buffer[0] = '\0';
	 send_buffer = "";

	ii=0;
//Delay for reply
	while(ii<500000){
		ii++;
	}

	}
	return 0;
	}
