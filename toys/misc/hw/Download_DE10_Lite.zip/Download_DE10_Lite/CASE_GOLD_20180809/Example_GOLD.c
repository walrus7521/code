/*
 * main.c
 *
 *  Created on: 14 jun 2018
 *      Author: Calle Melander
 */
/*
 * main.c
 *
 *  Created on: 16 mar 2018
 *      Author: Calle Melander
 *
 *      Testprogram with some external components
 */

#include <altera_avalon_sierra_ker.h>
#include <altera_avalon_sierra_io.h>
#include <altera_avalon_sierra_regs.h>
#include <altera_avalon_sierra_name.h>
#include <system.h>
#include <stdio.h>
#include <io.h>
#include <altera_avalon_pio_regs.h>
#include <altera_avalon_timer_regs.h>
#include <altera_up_avalon_rs232.h>
#include <draw_vga.h>
#include <DE10_Lite_VGA_Driver.h>
#include <DE10_Lite_Arduino_Driver.h>

#define LEDR_0 0x1
#define LEDR_1 0x2
#define LEDR_2 0x4
#define LEDR_3 0x8
#define LEDR_4 0x10
#define LEDR_5 0x20

#define ANALOG_VOLTAGE_REFERENCE 2.5f
#define CH1 0
#define CH2 1
#define CH3 2
#define CH4 3
#define CH5 4
#define CH6 5
#define SLOT_OFFSET 4

alt_u32 strlen(char *s);
#define background_color 0x7

// TASK, in Sierra
#define IDLE 0
#define TASK_B 1
#define TASK_C 2
#define TASK_A 3
#define TASK_E 4

// TASK STACKS
#define STACK_SIZE 800
char idle_stack[STACK_SIZE];
char task_b_stack[STACK_SIZE];
char task_c_stack[STACK_SIZE];
char task_e_stack[STACK_SIZE];

void vga_test_pattern(){
	alt_u32 x,y,ii,jj,color;
	for(y=0;y<240;y++) {
		color = 0;
		x = 0;
		for(ii=0;ii<64;ii++) {
			for(jj=0;jj<4;jj++){
				x = x+1;
				write_pixel(x,y,color);
			}
			x = x+1;
			color= color+1;
		}
	}
}




alt_u32 read_write_test() {
	alt_u32 write_color=0x2;
	write_pixel(100,100,write_color);
	alt_u32 read_color=read_pixel(100,100);

	if(read_color==write_color) {
		return 1;
	}

	return 0;
}

void draw_box(alt_u32 box_x,alt_u32 box_y,alt_u32 color,alt_u32 direction) {
	alt_u32 x,y;
	for(y=0;y<12;y++) {
		for(x=0;x<12;x++) {
			write_pixel(box_x+x,box_y+y,color);
		}
	}
	if(direction<1){
	draw_angled_line(box_x,box_y,box_x+11,box_y+11,(color==background_color)?background_color:0x3);
	}else{
		draw_angled_line(box_x,box_y+11,box_x+11,box_y,(color==background_color)?background_color:0x2);
	}
}



//-----------------------------------------------------
void task_B_code(void)
{
    int ledpio=0;
    printf("Task B init VGA \n ");
    init_period_time(2); // half second period time

	clear_screen(background_color);

	int i;
	for(i=0;i<1000000;i++) {};

	vga_test_pattern();

	// Initiate read and write test
	if(read_write_test()) {
		printf("Reading and writing to VRAM works\n");
	} else {
		printf("Error writing and/or reading to VRAM\n");
	}

	// Set up box start values

	alt_u32 box_color=0x0;
	alt_u32 direction=0;
	float box_x=50.0f;
	float box_y=53.0f;
	float box_velocity_x=1.0f;
	float box_velocity_y=0.8f;


    while(1) // Loop forever
    {
      wait_for_next_period(); //Every half second
     // printf("\nB ");
      // clear previous box to background color
      		draw_box((alt_u32)box_x,(alt_u32)box_y,background_color,direction);

      		// Calculate new box position
      		float box_increment_x=box_x+box_velocity_x;
      		float box_increment_y=box_y+box_velocity_y;

      		if(box_increment_x>=310.0f||box_increment_x<=0.0f) {
      			box_velocity_x*=-1.0f;
      		}
      		if(box_increment_y>=230||box_increment_y<=0.0f) {
      			box_velocity_y*=-1.0f;
      		}

      		box_x+=box_velocity_x;
      		box_y+=box_velocity_y;

      		if((box_velocity_x<0 && box_velocity_y>0)||(box_velocity_x>0 && box_velocity_y<0)){
      			direction=1;
      		}else{
      			direction=0;
      		}

      		// draw new position
      		draw_box((alt_u32)box_x,(alt_u32)box_y,box_color,direction);

    }
}

//-----------------------------------------------------
void task_C_code(void)
{
    printf("Task C initBT\n ");
    init_period_time(100); // every other second period time
	printf("Starting system\n");

	char rx_buffer[127];
	char tx_buffer[127]; // AT test
	alt_u32 testa;
	char *send_buffer;

	alt_u8 rx_txt;
	alt_u8 par_e;
	alt_32 fifo_lenght,ii;
	alt_u32 led0=1, led1=1, led2=1, led3=1, led4=1, led5=1;
	alt_u32 PIO_REG = 0x0;

    // open arduino uart pinns

	arduino_uart_mode(UART_ON);
	//open rs232
	alt_up_rs232_dev* rs232_if= alt_up_rs232_open_dev(RS232_0_NAME);
	alt_u8 rs232_available=(rs232_if!=0);
	if(!rs232_available) {
		printf("Failed to obtain Serial device pointer\n");
	}else{
			char AT_buffer[] = "AT+VERSION";
			for(ii=0;ii<10;ii++){
				alt_up_rs232_write_data(rs232_if,AT_buffer[ii]);
			}
			ii=0;//wait for reply
			while(ii<500000){
				ii++;
			}
			fifo_lenght = alt_up_rs232_get_used_space_in_read_FIFO(rs232_if);
			if(fifo_lenght!=0){
				printf("Connection to: ");
			}else{
				printf("Serial connection 9600baud 1 stopbit no parity.\n");
			}
	}

    while(1) // Loop forever
    {
      wait_for_next_period(); //Every other second
//  	arduino_pin_mode(0, 2);
//  	arduino_pin_mode(1,PIN_UART);
      printf("\nC-BT ");
		  		fifo_lenght = alt_up_rs232_get_used_space_in_read_FIFO(rs232_if);

		if(fifo_lenght!=0){
			for(ii=0;ii<fifo_lenght;ii++){
				alt_up_rs232_read_data(rs232_if,&rx_txt,&par_e);
				rx_buffer[ii] = rx_txt;
			}
			rx_buffer[fifo_lenght] = '\0';
			printf("%s\n",rx_buffer);//visa vad som mottogs Nios console
		}

		testa = rx_buffer[0];
		PIO_REG = IORD_ALTERA_AVALON_PIO_DATA(PIO_LEDS_OUT_BASE);

		switch(testa){
		case '0':
			printf("rx:0\n"); //Nios console
			if(led0==0){
				send_buffer = "Ledr_0 OFF \n";//Bluetooth console
				IOWR_ALTERA_AVALON_PIO_DATA(PIO_LEDS_OUT_BASE,PIO_REG & ~LEDR_0);
				led0 =1;
			}else{
				send_buffer = "Ledr_0 ON \n";//Bluetooth console
				IOWR_ALTERA_AVALON_PIO_DATA(PIO_LEDS_OUT_BASE,PIO_REG | LEDR_0);
				led0 =0;
			}
			break;
		case '1':
			printf("rx:1\n");
			if(led1==0){
				send_buffer = "Ledr_1 OFF \n";
				IOWR_ALTERA_AVALON_PIO_DATA(PIO_LEDS_OUT_BASE,PIO_REG & ~LEDR_1);
				led1 =1;
			}else{
				send_buffer = "Ledr_1 ON \n";
				IOWR_ALTERA_AVALON_PIO_DATA(PIO_LEDS_OUT_BASE,PIO_REG | LEDR_1);
				led1 =0;
			}
			break;
		case '2':
			printf("rx:2\n");
			if(led2==0){
				send_buffer = "Ledr_2 OFF \n";
				IOWR_ALTERA_AVALON_PIO_DATA(PIO_LEDS_OUT_BASE,PIO_REG  & ~LEDR_2);
				led2 =1;
			}else{
				send_buffer = "Ledr_2 ON \n";
				IOWR_ALTERA_AVALON_PIO_DATA(PIO_LEDS_OUT_BASE,PIO_REG  | LEDR_2);
				led2 =0;
			}
			break;
		case '3':
			printf("rx:3\n");
			if(led3==0){
				send_buffer = "Ledr_3 OFF \n";
				IOWR_ALTERA_AVALON_PIO_DATA(PIO_LEDS_OUT_BASE,PIO_REG & ~LEDR_3);
				led3 =1;
			}else{
				send_buffer = "Ledr_3 ON \n";
				IOWR_ALTERA_AVALON_PIO_DATA(PIO_LEDS_OUT_BASE,PIO_REG | LEDR_3);
				led3 =0;
			}
			break;
		case '4':
			printf("rx:4\n");
			if(led4==0){
				send_buffer = "Ledr_4 OFF \n";
				IOWR_ALTERA_AVALON_PIO_DATA(PIO_LEDS_OUT_BASE,PIO_REG & ~LEDR_4);
				led4 =1;
			}else{
				send_buffer = "Ledr_4 ON \n";
				IOWR_ALTERA_AVALON_PIO_DATA(PIO_LEDS_OUT_BASE,PIO_REG | LEDR_4);
				led4 =0;
			}
			break;
		case '5':
			printf("rx:5\n");
			if(led5==0){
				send_buffer = "Ledr_5 OFF \n";
				IOWR_ALTERA_AVALON_PIO_DATA(PIO_LEDS_OUT_BASE,PIO_REG & ~LEDR_5);
				led5 =1;
			}else{
				send_buffer = "Ledr_5 ON \n";
				IOWR_ALTERA_AVALON_PIO_DATA(PIO_LEDS_OUT_BASE,PIO_REG | LEDR_5);
				led5 =0;
			}
			break;
		case '-':
			led0=1, led1=1, led2=1, led3=1, led4=1, led5=1;
			PIO_REG =0x0;
			IOWR_ALTERA_AVALON_PIO_DATA(PIO_LEDS_OUT_BASE,PIO_REG);
			send_buffer = "ZERO  nollst�llt\n";
			break;
		}

		fifo_lenght = strlen(send_buffer);
		for(ii=0;ii<fifo_lenght;ii++){
			alt_up_rs232_write_data(rs232_if,send_buffer[ii]);
		}

		//Reset rx buffer
		rx_buffer[0] = '\0';
		send_buffer = "";


////////////////////////////////////////////
////	AT SERVICE TEST
/*		printf("serial_cmd>");
		scanf("%s", tx_buffer);
		fifo_lenght = strlen(tx_buffer);
		for(ii=0;ii<fifo_lenght;ii++){
			alt_up_rs232_write_data(rs232_if, tx_buffer[ii]);
		}
*/
////////////////////////////////////////////

    }
}

//-----------------------------------------------------
void task_E_code(void)
{
    int ledpio=0;
    printf("Task E init ADC\n ");
    init_period_time(55); // half second period time

	// Enable analog input from ADC in continuous mode
	adc_set_mode_run_continuously(MODULAR_ADC_0_SEQUENCER_CSR_BASE);
	adc_start(MODULAR_ADC_0_SEQUENCER_CSR_BASE);

	alt_u32 ii;
	alt_u32 reading;
	float temperature_c;

    while(1) // Loop forever
    {
      wait_for_next_period(); //Every half second
      printf("\nE-ADC ");
  	// Try to read TMP36 temperature sensor from arduino PIN_A0
  		alt_adc_word_read(MODULAR_ADC_0_SAMPLE_STORE_CSR_BASE+(CH1*SLOT_OFFSET),&reading,1);
  		alt_u32 pin_a0_reading=reading;

  		// Try to read 1Kohm potentiometer sensor from arduino PIN_A2
  		alt_adc_word_read(MODULAR_ADC_0_SAMPLE_STORE_CSR_BASE+(CH3*SLOT_OFFSET),&reading,1);
  		alt_u32 pin_a2_reading=reading;

  		// Try to read Photoresiostor sensor from arduino PIN_A4
  		alt_adc_word_read(MODULAR_ADC_0_SAMPLE_STORE_CSR_BASE+(CH5*SLOT_OFFSET),&reading,1);
  		alt_u32 pin_a4_reading=reading;


  		// Convert reading to voltage and celsius
  		float voltage=((pin_a0_reading<<1)*ANALOG_VOLTAGE_REFERENCE)/4096.0f;
  		 temperature_c=(voltage-0.5f)*100.0f;
  		float potvolt=((pin_a2_reading<<1)*ANALOG_VOLTAGE_REFERENCE)/4096.0f;
  		float voltlight=((pin_a4_reading<<1)*ANALOG_VOLTAGE_REFERENCE)/4096.0f;

  		// Print collected data
  		printf("Temp: %.2f celsius (%.2fv)\tPotentiometer %.2fv\tLjus %.2fv \n",temperature_c,voltage,potvolt,voltlight);

    }
}

//-----------------------------------------------------

void idle_task_code(void){
    /* Never blocked. Idle shall only be in running or ready state, lowest priority and taskid 0 */
    int i=0;
  while(1) // Loop forever!
   {for(i=0; i<50000; i++); //
    printf(".");
  }
}

/*!-----------------------------------------------------
    Main
-------------------------------------------------------*/

int main (void)
{
  Sierra_Initiation_HW_and_SW();
  //Get HW Version
  printf("  Sierra HW version = %d\n", sierra_HW_version());
  printf("  Sierra SW driver version = %d\n", sierra_SW_driver_version());

  /*********************************************************************
   * Initialize time base register.
   * This example     : 50 MHz system-clock
   * Wanted tick time : 20 ms (50Hz)
   * Formula gives    : 20 ms x 50 MHx / 1000 => 1000(dec)
   * ******************************************************************/
   set_timebase(1000);

/* task_create()  */
task_create(IDLE, 0, READY_TASK_STATE, idle_task_code, idle_stack, STACK_SIZE);
task_create(TASK_B, 6, READY_TASK_STATE, task_B_code, task_b_stack, STACK_SIZE);
task_create(TASK_C, 2, READY_TASK_STATE, task_C_code, task_c_stack, STACK_SIZE);
task_create(TASK_E, 6, READY_TASK_STATE, task_E_code, task_e_stack, STACK_SIZE);

// Start the Sierra scheduler
  tsw_on(); // enable CPU irq from Sierran and now at least idle will give a irq.

  while(1) {
    // Should never end up here...!
    printf ("* ERROR! SYSTEM FAILED *\n ");
  }
}




