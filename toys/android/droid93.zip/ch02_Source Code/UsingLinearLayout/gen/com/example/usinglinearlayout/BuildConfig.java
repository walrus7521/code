/** Automatically generated file. DO NOT MODIFY */
package com.example.usinglinearlayout;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}