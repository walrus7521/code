/** Automatically generated file. DO NOT MODIFY */
package net.learn2develop.spinner;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}