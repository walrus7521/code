/* -*- indent-tabs-mode:T; c-basic-offset:8; tab-width:8; -*- vi: set ts=8:
 * $Id: Vector_Rotate.h,v 2.0 2002/09/22 02:07:32 tramm Exp $
 *
 * (c) Aaron Kahn
 * (c) Trammell Hudson
 *
 * Vector rotation code
 *
 *************
 *
 *  This file is part of the autopilot simulation package.
 *
 *  For more details:
 *
 *	http://autopilot.sourceforge.net/
 *
 *  Autopilot is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  Autopilot is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Autopilot; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
#ifndef _Vector_Rotate_h
#define _Vector_Rotate_h

#include <mat/Vector.h>
#include <mat/Quat.h>
#include <cmath>

namespace libmat
{

/*
 *  Rotate a vector by one angle.  This is not thread safe, but
 * fast for repeatedly rotating about the same angle.
 */
extern const Vector<3>
rotate2(
	const Vector<3> &	v_in,
	const double		theta
);


/**
 *  Rotate a vector from one coord system to another.
 */
template<
	class			T
>
static inline const Vector<3,T>
rotate3(
	const Vector<3,T> &	v_in,
	const Vector<3,T> &	theta
)
{
	return eulerDC( theta ) * v_in;
}


}
#endif
